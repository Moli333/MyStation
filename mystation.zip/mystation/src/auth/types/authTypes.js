export const authTypes = {
    login: '[AUTH] login',
    logout: '[AUTH] logout',
    errors: '[AUTH] errors',
    spotifyConnect: 'SPOTIFY_CONNECT',
};
